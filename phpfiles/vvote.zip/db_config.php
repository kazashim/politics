<?php

/*
 * All database connection variables
 */

define('DB_USER', "root"); // db user
define('DB_PASSWORD', "mysql"); // db password (mention your db password here)
define('DB_DATABASE', "Vvote"); // database name
define('DB_SERVER', "localhost:3306"); // db server
?>
